import { useState } from "react";

const UpdatePage = ({onupdate}) => {
    const [updatedval , setUpdatedVal] =useState({
        id:null,
        text:"",
        isCompleted:false
    })

    return ( 
        <div>
            <input onChange={(e)=>setUpdatedVal((oldval)=>({...oldval  , text:e.target.value }))} value={updatedval.text} />
            <button  onClick={()=>onupdate(updatedval)} >update</button>
        </div>
     );
}
 
export default UpdatePage;