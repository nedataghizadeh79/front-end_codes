import { useState } from "react";

const TodoForm = ({ addTodoHandler }) => {
  const [input, setInput] = useState("");

  const changeHandler = (e) => {
    setInput(e.target.value);
  };

  const submitHandler = (e) => {
    e.preventDefault();
    if (!input) {
      alert("write your input");
      return;
    }
    addTodoHandler(input);
    setInput("");
  };

  return (
    <form type="submit" onSubmit={submitHandler} className="TodoForm">
      <input value={input} onChange={changeHandler} />
      <button type="submit" className="add">
        add
      </button>
    </form>
  );
};

export default TodoForm;
