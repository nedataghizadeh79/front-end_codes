const Todo = ({todo , completeHandler , editHandler}) => {
    return ( 
        <div className="todo">
            <p className={todo.isCompleted? "isCompleted":""}   >{todo.text}</p>
            <button onClick={editHandler}>edit</button>
            <button onClick={completeHandler}>complete</button>
        </div>
     );
}
 
export default Todo;