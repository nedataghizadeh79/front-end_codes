import './App.css'
import TodoApp from './TodoApp';

const App = () => {
    return ( 
        <div className='App'>
             <TodoApp/>
         </div>
     );
}
 
export default App;