import TodoForm from "./TodoForm";
import TodoList from "./TodoList";
import { useEffect, useState } from "react";
import Navbarr from "./Navbarr";
import UpdatePage from "./updatePage";

const TodoApp = () => {
    const [filteredTodo , setFilteredTodo]=useState([])
    const[status , setStatus]=useState("")
  const [todos, setTodos] = useState([]);
  // const [uppage , setUpgate]=useState(false)
  const[idd , setId]=useState(null)

  const addTodoHandler = (input) => {
    const newTodo = {
      id: Math.floor(Math.random() * 1000),
      text: input,
      isCompleted: false,
    };
    setTodos([...todos, newTodo]);
  };

  const completeHandler=(id)=>{
    const index=todos.findIndex((t)=>t.id===id)
    const myTodo={...todos[index]}
    myTodo.isCompleted= !myTodo.isCompleted
    const all=[...todos]
    all[index]=myTodo
    setTodos(all)
  }

  useEffect(()=>{
    filteredTodos(status);
  },[todos , status])

  const filteredTodos =(status)=>{
    if(status==="completed"){
        setFilteredTodo(todos.filter((t)=>t.isCompleted))
    }
    else if(status==="uncompleted"){
        setFilteredTodo(todos.filter((t)=> !t.isCompleted))
    }
    else{
        setFilteredTodo(todos)
    }
  }


const editHandler=(id)=>{
   setId(id)
}


const onupdate=(newval)=>{
    const index=todos.findIndex((t)=>t.id===idd)
    const myTodo={...todos[index]}
    myTodo.text= newval.text
    myTodo.isCompleted=newval.isCompleted
    const all=[...todos]
    all[index]=myTodo
    setTodos(all)
    setId(null)
    // setUpgate(false)
}
  

  return (
    <div className="container">
    <Navbarr status={status} setStatus={setStatus} filteredTodos={filteredTodos} uncpmpletedTodos={todos.filter((u)=>!u.isCompleted).length} />
    <TodoForm  addTodoHandler={addTodoHandler} />
    { idd  ? <UpdatePage onupdate={onupdate} />: <  TodoList todos={filteredTodo} editHandler={editHandler} completeHandler={completeHandler} />}
    </div>
  );
};

export default TodoApp;
