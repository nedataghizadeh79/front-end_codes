import { useState } from "react";

const Navbarr = ({uncpmpletedTodos , filteredTodos , setStatus , status}) => {
    
    const changeHandler =(e)=>{
        setStatus(e.target.value)
        filteredTodos(e.target.value)
    }
    return ( 
        <div>
            <p className="uncpmpletedTodos"> {uncpmpletedTodos}</p>

            <select onChange={changeHandler} value={status} >
                <option value="all">all</option>
                <option value="completed">completed</option>
                <option value="uncompleted">uncompleted</option>
            </select>


        </div>
     );
}
 
export default Navbarr;