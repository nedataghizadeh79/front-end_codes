import { useState } from "react";
import axios from "axios";

import "./NewComments.css";
const NewComments = ({onAddPost}) => {

  const [comment, setComment] = useState({
    name: "",
    email: "",
    body: "",
  });

  //   const nameHandler = (e) => {
  //     setComment({ ...comment, name: e.target.value });
  //   };

  //   const emailHandler = (e) => {
  //     setComment({ ...comment, email: e.target.value });
  //   };

  //   const bodyHandler = (e) => {
  //     setComment({ ...comment, body: e.target.value });
  //   };

  const changeHandler = (e) => {
    setComment({ ...comment, [e.target.name]: e.target.value });
  };



  return (
    <div className="newComments">
      <div>
        <label>name</label>
        <input type="text" name="name" onChange={changeHandler} />
      </div>
      <div>
        <label>email</label>
        <input type="email" name="email" onChange={changeHandler} />
      </div>
      <div>
        <label>body</label>
        <input type="textarea" name="body" onChange={changeHandler} />
      </div>
      <button onClick={()=>onAddPost(comment)}> add new comment</button>
    </div>
  );
};

export default NewComments;
