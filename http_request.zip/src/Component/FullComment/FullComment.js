import { useEffect, useState } from "react";
import "./FullComment.css";
import axios from "axios";

const FullComment = ({ commentId, setComments , setSelectedId }) => {
  const [comment2, setComment2] = useState(null);

  useEffect(() => {
    if (commentId) {
      axios
        .get(`/comments/${commentId}`)
        .then((response) => {
          setComment2(response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [commentId]);

  const styles = {
    color: "blue",
    backgroundColor: "#efefef",
    padding: "10px",
  };

  const spanStyle = {
    color: "red",
  };

  const clickHandler = () => {
    axios
      .delete(`/comments/${commentId}`)
      .then((res) => {
        return axios.get("/comments");
      })
      .then((res) => {
        setComments(res.data);
      }).then((res)=>{
          setComment2(null)
      }).then((res)=>{
        setSelectedId(null)
      })
      .catch((err) => console.log(err));
  };

  let commentDetail = <p style={styles}>please select a comment!</p>;

  if (commentId) {
    <p>loading...</p>;
  }

  if (comment2) {
    commentDetail = (
      <div className="fullComment">
        <p>
          <span style={spanStyle}>name :</span>
          {comment2.name}
        </p>
        <p>
          <span style={spanStyle}>email :</span>
          {comment2.email}
        </p>
        <p>
          <span style={spanStyle}>body :</span>
          {comment2.body}
        </p>
        <button onClick={clickHandler}>Delete</button>
      </div>
    );
    return commentDetail;
  }
};

export default FullComment;
