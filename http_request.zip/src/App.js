import Discussion from "./Container/Discussion/Discussion";
import "./App.css";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const App = () => {
  return (
    <div className="App">
      <Discussion />
      <ToastContainer />
    </div>
  );
};

export default App;
