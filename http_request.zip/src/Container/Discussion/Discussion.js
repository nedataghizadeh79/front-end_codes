import { useEffect, useState } from "react";
import Comment from "../../Component/Comments/Commet";
import FullComment from "../../Component/FullComment/FullComment";
import NewComments from "../../Component/NewComments/NewComments";
import "./Discussion.css";
import { ToastContainer, toast } from 'react-toastify';
import http from "../../services/httpServices";

const Discussion = () => {
  const [comments, setComments] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    http
      .get("/comments")
      .then((response) => {
        setComments(response.data);
      })
      .catch((error) => {
        setError(true);
      });
  }, []);

  const selectCommentHandler = (id) => {
    setSelectedId(id);
  };

  const postCommentHandler = (comment) => {
    http
      .post("/comments", {
        ...comment,
        postId: 10,
      })
      .then((res) => {
        return http.get("/comments");
      })
      .then((res) => setComments(res.data))
      .catch();
  };


  const renderComents = () => {
    let rendereddComments = <p>loading...</p>;
    if (error) {
      rendereddComments = <p>fuck you and we have error</p>;
      toast.error("there is an error in toast")
    }
    if (comments) {
      rendereddComments = comments.map((c) => (
        <Comment
          key={c.id}
          name={c.name}
          email={c.email}
          onClick={() => selectCommentHandler(c.id)}
        />
      ));
    }

    return rendereddComments;
  };

  return (
    <main>
      <section>{renderComents()}</section>
      <section>
        <FullComment commentId={selectedId} setComments={setComments}  setSelectedId={setSelectedId} />
      </section>
      <section>
        <NewComments onAddPost={postCommentHandler} />
      </section>
    </main>
  );
};

export default Discussion;
