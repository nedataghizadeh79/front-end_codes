import { useEffect, useState } from "react";
import OverView from "./OverView";
import TransActions from "./TransActions";

const ExpenseApp = () => {
  const [income, setIncome] = useState(0);
  const [expense, setExpense] = useState(0);
  const [transActions, setTransActions] = useState([]);

  const addTransaction = (inputValue) => {
    setTransActions([...transActions, { ...inputValue, id: Date.now() }]);
  };

  useEffect(() => {
    let inc = 0;
    let exp = 0;

    transActions.forEach((t) => {
      if (t.type === "income") {
        inc = inc + parseInt(t.amount);
      } else {
        exp = exp + parseInt(t.amount);
      }
    });
    setExpense(exp);
    setIncome(inc);
  }, [transActions]);

  return (
    <div className="container">
      <OverView
        income={income}
        expense={expense}
        addTransaction={addTransaction}
      />
      <TransActions transActions={transActions} />
    </div>
  );
};

export default ExpenseApp;
