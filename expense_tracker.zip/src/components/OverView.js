import { useState } from "react";
import TransActionForm from "./TransActionForm";

const OverView = ({ expense, income , addTransaction }) => {
    const [isShow , setIsshow]=useState(false)
  return (
    <div>
      <div className="topsection">
        <p> balance: {income - expense}</p>
        <button onClick={()=>setIsshow(!isShow)} >{isShow ? "cancle":"add"}</button>
      </div>
      {isShow && <TransActionForm addTransaction={addTransaction} />}

      <div className="resultSection">
        <p className="expenseBox">expense : {expense}</p>
        <p className="expenseBox">  income: {income}</p>
      </div>
    </div>
  );
};

export default OverView;
