import { useState } from "react";

const TransActionForm = ({ addTransaction }) => {
  const [formVal, setFormVal] = useState({
    type:"expense",
    desc: "",
    amount: 0,
  });

  const changeHandler = (e) => {
    setFormVal({ ...formVal, [e.target.name]: e.target.value });
  };


  const submitHandler = (e) => {
    e.preventDefault();
    addTransaction(formVal);
  };

  return (
    <form onSubmit={submitHandler}>
      <div className="inputs">
        <input
          type="text"
          value={formVal.desc}
          name="desc"
          onChange={changeHandler}
        />
        <input
          type="number"
          value={formVal.amount}
          name="amount"
          onChange={changeHandler}
        />
      </div>

      <div>
        <input
          type="radio"
          value="expense"
          name="type"
          id="ex"
          onChange={changeHandler}
          checked={formVal.type === "expense"}
        />
        <label htmlFor="ex" >expense</label>
        <input
        id="income"
          type="radio"
          value= "income"
          name="type"
          onChange={changeHandler}
          checked={formVal.type === "income"}
        />
        <label htmlFor="income">income</label>
      </div>
      <button type="submit">add transaction</button>
    </form>
  );
};

export default TransActionForm;
