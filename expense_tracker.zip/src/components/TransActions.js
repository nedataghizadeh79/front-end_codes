import { render } from "@testing-library/react";
import { useEffect, useState } from "react";

const TransActions = ({ transActions }) => {
  const [searchedItem, setSearchedItem] = useState("");
    const [filteredTransaction , setFilteredTransaction]=useState( transActions)

const filterTransactionFunc=(searched)=>{
    if (searched==="" || searchedItem.length===0){
        setFilteredTransaction(transActions)
        return
    }
     const filtered= transActions.filter((t)=> t.desc.toLowerCase().includes(searched.toLowerCase()) )
     setFilteredTransaction(filtered)

}


  const changeHandler = (e) => {
    setSearchedItem(e.target.value)
    filterTransactionFunc(e.target.value)
  };

  useEffect(()=>{
    filterTransactionFunc(searchedItem)
  },[transActions])

  return (
    <section>
      <input type="text" value={searchedItem} onChange={changeHandler}  className="searched" />
      {filteredTransaction.length ?
        filteredTransaction.map((t) => (
          <div
            className="show"
            key={t.id}
            style={{
              borderRight:
                t.type === "expense" ? "4px red solid " : "4px solid green",
            }}
          >
            <span> {t.desc} </span>
          </div>
        ))  :   <p className="p">add some data for search</p>}
    </section>
  );
};

export default TransActions;
