import './App.css'
import ExpenseApp from './components/ExpenseApp';
 
const App = () => {
    return ( 
        <div className='App'>
               <header>expense tracker</header>
               <ExpenseApp/>
         </div>
     );
}
 
export default App;