const Todo = ({ todo , onEdit , onComplete , onDelete }) => {



  return (
    <div  className="todo" >
          <div  onClick={onComplete} className={`todoText ${todo.isCompleted ? "completed":""}  `} >{todo.text}</div>
          <div>
            <button  className="edit" 
            onClick={onEdit}>Edit</button>
            <button className="edit remove" 
            onClick={onDelete} >Delete</button>
          </div>
        </div>
  );
};

export default Todo;
