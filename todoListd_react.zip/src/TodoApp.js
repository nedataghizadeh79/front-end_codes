import { useEffect, useState } from "react";
import Navbar from "./Navbar";
import TodoForm from "./TodoForm";
import TodoList from "./TodoList";

const TodoApp = () => {
  const [status, setStatus] = useState("All");
  const [todos, setTodos] = useState([]);
  const [filteredTodos, setFilteredTodos] = useState([]);

  useEffect(() => {
    filterTodos(status);
  }, [todos, status]);

  const addTodoHandler = (input) => {
    const newTodo = {
      id: Math.floor(Math.random() * 1000),
      text: input,
      isCompeletd: false,
    };
    setTodos([...todos, newTodo]);
  };

  const filterTodos = (status) => {
    switch (status) {
      case "Completed":
        setFilteredTodos(todos.filter((t) => t.isCompeletd));
        break;

      case "UnCompleted":
        setFilteredTodos(todos.filter((t) => !t.isCompeletd));
        break;

      default:
        setFilteredTodos(todos);
    }
  };

  const completeTodo = (id) => {
    const index = todos.findIndex((t) => t.id === id);
    const selectedTodo = { ...todos[index] };
    selectedTodo.isCompeletd = !selectedTodo.isCompeletd;
    const allTodos = [...todos];
    allTodos[index] = selectedTodo;
    setTodos(allTodos);
  };

  const deleteHandler = (id) => {
    setTodos(todos.filter((t) => t.id !== id));
  };

  const updateTodo = (id, newVal) => {
    const index = todos.findIndex((t) => t.id === id);
    const selectedTodo = { ...todos[index] };
    selectedTodo.text = newVal;
    const allTodos = [...todos];
    allTodos[index] = selectedTodo;
    setTodos(allTodos);
  };

  return (
    <div className="container">
      <Navbar
        status={status}
        setStatus={setStatus}
        unCompletedTodos={todos.filter((t) => !t.isCompeletd).length}
        filterTodos={filterTodos}
      />
      <TodoForm addTodoHandler={addTodoHandler} />
      <TodoList
        todos={filteredTodos}
        onComplete={completeTodo}
        onDelete={deleteHandler}
        onUpdate={updateTodo}
      />
    </div>
  );
};

export default TodoApp;
