import {useState} from 'react'

const Navbar = ({ uncompletedTodos  , filterTodos }) => {
const [status , setStstus]=useState("All")

   const chsngeHandler=(e)=>{
        setStstus(e.target.value)
        filterTodos(e.target.value)
    }

  if (!uncompletedTodos) return <h2>set your today todos</h2>;
  return (
    <header>
      <>
        <span>{uncompletedTodos}</span> <h2> are not completed</h2>
        <select onChange={chsngeHandler} value={status}>
            <option value="All">All</option>
            <option value="Completed">Completed</option>
            <option value="uncompleted">uncompleted</option>
        </select>
      </>
    </header>
  );
};

export default Navbar;
