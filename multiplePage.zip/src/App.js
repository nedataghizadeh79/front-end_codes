import { Route, BrowserRouter, Switch } from "react-router-dom";
import Navigation from "./Components/Navigation";
import Layout from "./LayOut/Lauout";
import AboutUs from "./pages/AboutUs";
import Lauout from "./LayOut/Lauout";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import Profile from "./pages/Profile";
import Routers from "./Routers";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Lauout>
          <Switch>
            {Routers.map((route , index) => (
              <Route {...route}  key={index} />
            ))}
          </Switch>

          {/* <Route path="/" exact={true} component={Home} />
        <Route path="/AboutUs" component={AboutUs} />
        <Route path="/NotFound" component={NotFound} />
        <Route path="/Profile" component={Profile} /> */}
        </Lauout>
      </BrowserRouter>
    </div>
  );
}

export default App;
