import { Link, Route } from "react-router-dom";
import dashboard from "../Components/dashboard";
import download from "../Components/download";
import SideBar from "../Components/SideBar";
import Layout from "../LayOut/Lauout";

const Profile = () => {
  return (
    <>
      <p> welcome guys </p>
      <div className="sideBar" >
      <SideBar />
      <Route path="/Profile/dashboadrd" component={dashboard} />
      <Route path="/Profile/download" component={download} />
      </div>
    </>
  );
};

export default Profile;
