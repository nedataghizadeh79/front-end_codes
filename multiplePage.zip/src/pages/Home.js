 
function Home(props) {
  // props.history.push('/AboutUs')
  return (
    
      <p> this is home page</p>
    
  );
}

export default Home;
