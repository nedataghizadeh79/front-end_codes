import { Link } from "react-router-dom";

const items = [
  { name: "Blog-1", to: "/Blog/1" },
  { name: "Blog-2", to: "/Blog/2" },
  { name: "Blog-3", to: "/Blog/3" },
];

const BlogPage = () => {
  return (
    <div>
      <h2>Blog page</h2>
      {items.map((item) => {
        return (
          <li key={item.to}>
            <Link to={ { pathname:item.to , search:"sort=name"} }>{item.name}</Link>
          </li>
        );
      })}
    </div>
  );
};

export default BlogPage;
