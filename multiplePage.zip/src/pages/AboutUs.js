import React from "react";
 
function AboutUs() {
  return (
    
      <h1>This is the AboutUs page</h1>
    
  );
}

export default AboutUs;
