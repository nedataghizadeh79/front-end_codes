import Blog from "./Components/Blog";
import AboutUs from "./pages/AboutUs";
import BlogPage from "./pages/BlogPage";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import Post from "./pages/Post";
import Profile from "./pages/Profile";

const Routers = [
   { path: "/Blog/:id", component: Blog },
   { path: "/Blog", component: BlogPage },
   { path: "/Profile", component: Profile },
   { path: "/AboutUs", component: AboutUs },
   { path: "/Post/:id?([0-9]+)", component: Post },
   { path: "/", component: Home, exact: true },
  { component: NotFound },
];
export default Routers;
