import Navigation from "./Navigation";

const Header = () => {
    return ( 
         <header>
            <Navigation/>
            <h2> its header</h2>
         </header>
     );
}
 
export default Header;