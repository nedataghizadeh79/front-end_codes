import { Link , NavLink } from "react-router-dom";

const SideBar = () => {
  return (
    <side>
      <ul className="aside">
        <li>
          <NavLink to="/Profile/dashboard"  activeClassName="activeTab" >dashboard </NavLink>
        </li>

        <li>
          <NavLink to="/Profile/download" activeClassName="activeTab"  >downloads </NavLink>
        </li>
      </ul>
    </side>
  );
};

export default SideBar;
