const download = () => {
    return ( 
        <div>
            downloads
        </div>
     );
}
 
export default download;