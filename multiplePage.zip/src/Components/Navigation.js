import { Link, NavLink, withRouter } from "react-router-dom";

const items = [
  { name: "Home", to: "/", exact: true },
  { name: "About-Us", to: "/AboutUs" },
  { name: "Profile", to: "/Profile" },
  { name: "Blog", to: "/Blog" },
  { name: "Post", to: "/Post" },
];

const Navigation = (props) => {
  return (
    <nav>
      <ul>
        {items.map((item) => {
          return (
            <li key={item.to}>
              <NavLink
                to={item.to}
                activeLink="activeLink"
                exact={item.exact || false}
              >
                {item.name}
              </NavLink>
            </li>
          );
        })}

        {/* <li>
          <Link  to="/">Home</Link>
        </li>
        <li>
          <Link to="/AboutUs">About-Us</Link>
        </li>
        <li>
          <Link to="/NotFound">Not-Found</Link>
        </li>
        <li>
          <Link  to="/Profile">Profile</Link>
        </li> */}
      </ul>
    </nav>
  );
};

export default withRouter(Navigation);
