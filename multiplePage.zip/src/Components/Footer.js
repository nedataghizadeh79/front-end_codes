const Footer = () => {
    return ( 
        <footer>
            this is footer
        </footer>
     );
}
 
export default Footer;