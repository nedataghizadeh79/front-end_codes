import { Link } from "react-router-dom";
import queryString from "query-string"

const Blog = ({location , match}) => {
    const query = queryString.parse(location.search)
    console.log(query)
    const id =match.params.id
    return ( 
        <div>
           <h2> detal of blog - {id}</h2> 
           <Link to={`/Blog/${parseInt(id)+1}`} >go to next Blog page</Link>
        </div>
     );
}
 
export default Blog;