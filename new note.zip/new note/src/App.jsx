import React from 'react';
import AllNotes from "./Compponents/AllNotes/AllNotes";

function App() {
    return (
        <div className='app'>
                <AllNotes/>
        </div>

    );
}

export default App;
