import './Headre.css'
import {useState} from "react";

export default function Header({all , complete , Uncompleted, sortOption, setSortOption}){
    const category = ["All", "Completed", "Uncompleted"]
    const [selectedCat, setSelectedCat] = useState("")

    function saveValueOption(e){
        setSortOption( e.target.value)
    }


        return(
            <div className='headerContainer'>
                {
                    category.map((cat, index)=>{
                        return(
                            <div key={index} onClick={()=>setSelectedCat(cat)} className={`category ${selectedCat===cat ? "bold":""} `} >
                                {cat} {cat==="All"? all:""} {cat==="Completed"? complete:""}  {cat==="Uncompleted"? Uncompleted:""}
                            </div>
                        )
                    })
                }


                <select value={sortOption} onChange={saveValueOption} className='select'>
                    <option value='latest'>latest</option>
                    <option value='recently'>recently</option>
                    <option value='completed'>completed</option>
                </select>

            </div>
        )
}
