import './CreatedNote.css'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faSquare as faSolidSquare } from "@fortawesome/free-solid-svg-icons";
import { faSquare as faRegularSquare } from "@fortawesome/free-regular-svg-icons";


export default function CreatedNote({notes, deleteNote, changeStatusToCompleted, changeStatusToIncomplete}) {

        return(
            <div className='createdNote'>
                {
                    notes.map( (note)=>{
                        return(
                            <div key={note.id} className='noteContainer'>
                                <div className='rowSection'>
                                    <div className='info'>
                                        <div className={`title ${note.status==="complete" ? "complete":""}`}>

                                            {note.title}
                                        </div>
                                        <div className={`description ${note.status==="complete"? "complete":""}`}>
                                            {note.description}
                                        </div>
                                    </div>
                                    <div className='icons'>
                                        <FontAwesomeIcon size='2x' onClick={()=>deleteNote(note.id)} icon={faTrash} />
                                        {
                                            note.status==="incomplete" ? <FontAwesomeIcon size='2x' onClick={()=>changeStatusToCompleted(note.id)}  icon={faRegularSquare} />
                                                :
                                                <FontAwesomeIcon size='2x' onClick={()=>changeStatusToIncomplete(note.id)} icon={faSolidSquare} />
                                        }
                                    </div>
                                </div>
                                <div className='date'>{note.date}</div>
                            </div>
                        )
                    } )
                }
            </div>
        )
}
