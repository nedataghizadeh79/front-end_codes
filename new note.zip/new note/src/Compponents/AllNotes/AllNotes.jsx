import './AllNotes.css'
import {useEffect, useState} from "react";
import NewNote from "../New Note/NewNote";
import Header from "../Header/Header";
import CreatedNote from "../CreatedNote/CreatedNote";

export default function AllNotes(){
    const [title, setTitle] = useState("")
    const [description, setDescription] = useState("")
    const [notes, setNotes] = useState([])
    const [sortOption, setSortOption] = useState('recently')

    const [filteredNotes, setFilteredNotes] = useState([])


useEffect(()=>{
    let updatedNotes = [...notes]
    if(sortOption==="completed"){
        updatedNotes = notes.filter(note => note.status === "complete")
    }else if (sortOption==="recently"){
        updatedNotes = notes.sort((a, b)=> new Date(b.date) - new Date(a.date) )
    }else {
        updatedNotes = notes.sort((a, b)=> new Date(a.date) - new Date(b.date) )
    }
    setFilteredNotes(updatedNotes)

},[notes, sortOption])


    function deleteNote(id) {
        setNotes( notes.filter( (note)=> note.id !== id ) )
    }

    function changeStatusToCompleted(id) {
        const selected = notes.find((note) => note.id === id)
        const updatedSelected = {...selected, status: "complete"}
        const filteredNotes = notes.filter((note)=> note.id !== id)
        const updatedNotes = [...filteredNotes, updatedSelected]
        setNotes(updatedNotes)
    }

    function changeStatusToIncomplete(id) {
        const selected = notes.find((note)=>note.id === id)
        const updatedSelected = {...selected, status: "incomplete"}
        const filteredNotes = notes.filter( (note)=> note.id !==id )
        const updatedNote = [...filteredNotes, updatedSelected]
        setNotes(updatedNote)
    }

    const completed = notes.filter( (note)=> note.status==="complete" )
    const Uncompleted = notes.filter( (note)=> note.status==="incomplete" )



    return(
        <div className='Whole'>
            <Header all={notes.length} complete={completed.length} Uncompleted={Uncompleted.length} sortOption={sortOption} setSortOption={setSortOption}/>
            <div className='allNotesContainer'>
                <NewNote title={title} setTitle={setTitle} description={description} setDescription={setDescription} setNotes={setNotes} />



                   <CreatedNote notes={filteredNotes} deleteNote={deleteNote} changeStatusToCompleted={changeStatusToCompleted} changeStatusToIncomplete={changeStatusToIncomplete}/>


            </div>
        </div>

    )

}
