import './NewNote.css'
import {useState} from "react";

export default function NewNote({title, setTitle, description, setDescription, setNotes}){
        const [id, setId] = useState(0)

        const newNote={
                "title":title,
                "description": description,
                "id": id,
                "status": "incomplete",
                "date": new Date().toISOString()
        }

        function addNewNote(){
                setId((prevState)=> prevState+1)
                setNotes( (prevState)=> [...prevState, newNote] )
                setTitle("")
                setDescription("")
        }

        return(
            <div className='NewNote'>
                <label> Add new note </label>
                <input placeholder='   title' value={title} onChange={(event)=> setTitle(event.target.value)}/>
                <input placeholder='   description' value={description} onChange={(event)=>setDescription(event.target.value)}/>
                <button onClick={()=>addNewNote()}>Add</button>
            </div>
        )
}
