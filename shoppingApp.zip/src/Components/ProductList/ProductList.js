import React, { Component } from "react";
import Product from "../Product/Product";

class ProductList extends Component {
  state = {
    product: [
      { title: "neda", price: "112", id: 1 },
      { title: "saee", price: "22", id: 2 },
      { title: "ngar", price: "33", id: 3 },
    ],
  };

  removeHandler = (id) => {
    console.log(id);
    const filteredProducts = this.state.product.filter((p) => p.id !== id);
    this.setState({ product: filteredProducts });
  };

  render() {
    return (
      <div>
        {this.state.product.map((productt, index) => {
          return (
            <Product
              name={productt.name}
              price={productt.price}
              key={index}
              onDelete={() => this.removeHandler(productt.id)}
            />
          );
        })}
      </div>
    );
  }
}

export default ProductList;
