import React, { Component } from "react";
import Product from "../Product/Product";


class ProductList extends Component {



  renderProduct=()=>{
    if (this.props.product.length===0){
      return <div>there is no product in cart</div>
    }
    
    return  this.props.product.map((productt, index) => {
      return (
        <Product
          // name={productt.name}
          // price={productt.price}
          // quantity={productt.quantity}
          product={productt}
          key={index}
          onRemove={() => this.props.onRemove(productt.id)}
          onIncrement={()=> this.props.onIncrement(productt.id)}
          onchnage={(e)=> this.props.onchnage(e, productt.id)}
          onDecrement={()=> this.props.onDecrement(productt.id)}
        />
      );
    })

  }


  render() {
    return (
      <div>
        {this.renderProduct()}
      </div>
    );
  }
}

export default ProductList;
