import style from './product.module.css'
import { FaTrashAlt } from "react-icons/fa";

const Product = (props) => {

    return ( 
        <div className={style.product} onClick={props.click} >
        <p>the product name is  {props.product.title} </p>
        <p>and it's price is  {props.product.price}</p>
        <span className={style.value} >{props.product.quantity}</span>
        <input type={"text"} onChange={props.onchnage}  value={props.product.title}  className={style.input} />
        <button  className={`${style.button}  ${style.inc}`}   onClick={props.onIncrement}  >increment</button>
        <button  onClick={props.onDecrement} className={`${style.button} ${style.decr}  ${props.product.quantity===1 && style.remove  }`}>  { props.product.quantity>1 ? "-": <FaTrashAlt/> } </button>
        <button onClick={props.onRemove}>delete</button>
        </div>

     );
}
 
export default Product; 











