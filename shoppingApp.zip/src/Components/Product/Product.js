import style from './product.module.css'

const Product = (props) => {
    return ( 
        <div className={style.product} onClick={props.click} >
        <p>hi my name is {props.name} </p>
        <p>and my price is {props.price}</p>
        <button onClick={props.onDelete}>delete</button>
        </div>

     );
}
 
export default Product; 