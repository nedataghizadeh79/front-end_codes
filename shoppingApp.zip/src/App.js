import ProductList from './Components/ProductList/ProductList';
import React, { Component } from 'react';
import './App.css'


class App extends Component {

    countHandler=(id)=>{
        console.log("count " ,  id)
        this.setState({count:this.state.count+1})
    }



    render() { 

        return ( 
            <div className="container" id="title">
                <h1>shopping app</h1>
                <ProductList/>
            </div>
         );

    }
}
 
export default App;






     












