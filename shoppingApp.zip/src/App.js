import ProductList from "./Components/ProductList/ProductList";
import React, { Component } from "react";
import "./App.css";
import Navbar from "./Components/Navbar/Navbar";


class App extends Component {
  state = {
    product: [
      { title: "neda", price: "112", id: 1 , quantity:2 },
      { title: "bahar", price: "22", id: 2 , quantity:1},
      { title: "ngar", price: "33", id: 3 , quantity:3},
    ],
  };


  
  removeHandler = (id) => {
    console.log(id);
    const filteredProducts = this.state.product.filter((p) => p.id !== id);
    this.setState({ product: filteredProducts });
  };

  incrementHandler=(id)=>{
     const index = this.state.product.findIndex( (p)=>p.id===id )
     const myProduct = {...this.state.product[index]}
     myProduct.quantity +=1
     const allProducts = [...this.state.product]
     allProducts[index]=myProduct
     this.setState({product:allProducts})
  }

  decrementHandler=(id)=>{
    const index = this.state.product.findIndex((p)=>p.id===id)
    const myProduct= {...this.state.product[index]}
    const allProducts=[...this.state.product]
    
     if (myProduct.quantity >1){
      myProduct.quantity-=1
      allProducts[index]=myProduct
      this.setState({product:allProducts})
    }
    else{
      this.removeHandler(id)
    }
   }

  changeHandler=(e,id)=>{
      const index= this.state.product.findIndex((p)=>p.id===id)
      const myProduct = {...this.state.product[index]}
      myProduct.title = e.target.value
      const allProducts= [...this.state.product]
      allProducts[index]=myProduct
      this.setState({product:allProducts})
  }




  render() {
    return (
      <div className="container" id="title">
        <Navbar
        totalItems={this.state.product.filter((p)=>p.quantity>0).length}
        />
        <ProductList
        product={this.state.product}
        onRemove={this.removeHandler}
        onIncrement={this.incrementHandler}
        onchnage={this.changeHandler}
        onDecrement={this.decrementHandler}
        />

      </div>
    );
  }
}

export default App;
