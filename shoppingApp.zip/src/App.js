import ProductList from "./Components/ProductList/ProductList";
import React, { Component } from "react";
import "./App.css";
import Navbar from "./Components/Navbar/Navbar";


class App extends Component {
  state = {
    product: [
      { title: "neda", price: "112", id: 1 , quantity:2 },
      { title: "bahar", price: "22", id: 2 , quantity:1},
      { title: "ngar", price: "33", id: 3 , quantity:3},
    ],
  };


  
  removeHandler = (id) => {
    console.log(id);
    const filteredProducts = this.state.product.filter((p) => p.id !== id);
    this.setState({ product: filteredProducts });
  };

  incrementHandler=(id)=>{
    const allProducts=[...this.state.product]
    const foundedProducts= allProducts.find((p)=> p.id===id)
    foundedProducts.quantity+=1
    this.setState({allProducts:allProducts})
  }

  decrementHandler=(id)=>{
    const allProducts=[...this.state.product]
    const foundedProduct=allProducts.find((p)=> p.id===id)
    if (foundedProduct.quantity >1){
      foundedProduct.quantity-=1

    }
    else{
      this.removeHandler(id)
    }
    this.setState(allProducts)
  }

  changeHandler=(e,id)=>{
      const allProducts=[...this.state.product]
      const foundedProducts = allProducts.find((p)=> p.id===id)
      foundedProducts.title=e.target.value
      this.setState(foundedProducts)
  }




  render() {
    return (
      <div className="container" id="title">
        <Navbar
        totalItems={this.state.product.filter((p)=>p.quantity>0).length}
        />
        <ProductList
        product={this.state.product}
        onRemove={this.removeHandler}
        onIncrement={this.incrementHandler}
        onchnage={this.changeHandler}
        onDecrement={this.decrementHandler}
        />

      </div>
    );
  }
}

export default App;
