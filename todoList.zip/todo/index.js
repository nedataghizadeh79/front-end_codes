const todoBtn = document.querySelector(".todo-button");
const todoInput = document.querySelector(".todo-input");
const todoList = document.querySelector(".todolist");
const filterOption = document.querySelector(".filter-todos");

todoBtn.addEventListener("click", addTodo);
todoList.addEventListener("click", checkRemove);
filterOption.addEventListener("click", filterTodos);
document.addEventListener("DomContentLoaded", getLocalTodos);

function addTodo(e) {
  e.preventDefault();
  const todoDiv = document.createElement("div");
  todoDiv.classList.add("todo"); //<div class="todo"></div>
  todoDiv.innerHTML = `
<li> ${todoInput.value}</li>
          <span><i class="fa-solid fa-check"></i></span>
          <span> <i class="fa-solid fa-trash-arrow-up"></i> </span>  
        `;
  todoList.appendChild(todoDiv);
  savedLocalTodos(todoInput.value);
  todoInput.value = "";
}

function checkRemove(e) {
  const classLists = [...e.target.classList];
  classLists.forEach((element) => {
    if (element === "fa-trash-arrow-up") {
      removeLocalTodos(e.target.parentElement.parentElement);
      e.target.parentElement.parentElement.remove();
    } else if (element === "fa-check") {
      e.target.parentElement.parentElement.classList.toggle("completed");
    }
  });
}

function filterTodos(e) {
  const todos = [...todoList.childNodes];
  todos.forEach((todo) => {
    switch (e.target.value) {
      case "all":
        todo.style.display = "flex";
        break;

      case "completed":
        if (todo.classList.contains("completed")) {
          todo.style.display = "flex";
        } else {
          todo.style.display = "none";
        }
        break;

      case "uncompleted":
        if (!todo.classList.contains("completed")) {
          todo.style.display = "flex";
        } else {
          todo.style.display = "none";
        }
        break;

      default:
        break;
    }
  });
}

function savedLocalTodos(todo) {
  let savedTodos = localStorage.getItem("todos")
    ? JSON.parse(localStorage.getItem("todos"))
    : [];

  savedTodos.push(todo);
  localStorage.setItem("todos", JSON.stringify(savedTodos));
}

function getLocalTodos() {
  let savedTodos = localStorage.getItem("todos")
    ? JSON.parse(localStorage.getItem("todos"))
    : [];

  savedTodos.forEach((todos) => {
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    todoDiv.innerHTML = `
     <li> ${todos}</li>
          <span><i class="fa-solid fa-check"></i></span>
          <span> <i class="fa-solid fa-trash-arrow-up"></i> </span>  
     `;
    todoList.appendChild(todoDiv);
  });
}

function removeLocalTodos(todo) {
  let savedTodos = localStorage.getItem("todos")
    ? JSON.parse(localStorage.getItem("todos"))
    : [];
  const filteredTodos = savedTodos.filter(
    (t) => t != todo.children[0].innerText
  );
  localStorage.setItem("todos", JSON.stringify(filteredTodos));
}
